using PixelCrushers.DialogueSystem;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LangChange_CM : MonoBehaviour
{
    public int langNum;
    public DatabaseManager dbMgr;
    public DialogueSystemTrigger dst1;
    public DialogueSystemTrigger dst2;

    void Start()
    {
        
    }

    public void DST1LangChange()
    {
        
    }
}
